
import { Player, Difficulty } from '../types';

const getBoardConfig = (difficulty: Difficulty) => {
  return difficulty === Difficulty.HARD 
    ? { size: 4, winCount: 3, maxDepth: 6 } 
    : { size: 3, winCount: 3, maxDepth: 9 };
};

export const checkWinner = (board: Player[], difficulty: Difficulty): { winner: Player | 'Draw' | null; winningLine: number[] | null } => {
  const { size, winCount } = getBoardConfig(difficulty);
  
  // Rows
  for (let r = 0; r < size; r++) {
    for (let c = 0; c <= size - winCount; c++) {
      const startIdx = r * size + c;
      if (!board[startIdx]) continue;
      const line = [startIdx];
      let match = true;
      for (let k = 1; k < winCount; k++) {
        const idx = r * size + (c + k);
        if (board[idx] !== board[startIdx]) {
          match = false;
          break;
        }
        line.push(idx);
      }
      if (match) return { winner: board[startIdx], winningLine: line };
    }
  }

  // Columns
  for (let c = 0; c < size; c++) {
    for (let r = 0; r <= size - winCount; r++) {
      const startIdx = r * size + c;
      if (!board[startIdx]) continue;
      const line = [startIdx];
      let match = true;
      for (let k = 1; k < winCount; k++) {
        const idx = (r + k) * size + c;
        if (board[idx] !== board[startIdx]) {
          match = false;
          break;
        }
        line.push(idx);
      }
      if (match) return { winner: board[startIdx], winningLine: line };
    }
  }

  // Diagonals (Top-left to bottom-right)
  for (let r = 0; r <= size - winCount; r++) {
    for (let c = 0; c <= size - winCount; c++) {
      const startIdx = r * size + c;
      if (!board[startIdx]) continue;
      const line = [startIdx];
      let match = true;
      for (let k = 1; k < winCount; k++) {
        const idx = (r + k) * size + (c + k);
        if (board[idx] !== board[startIdx]) {
          match = false;
          break;
        }
        line.push(idx);
      }
      if (match) return { winner: board[startIdx], winningLine: line };
    }
  }

  // Diagonals (Top-right to bottom-left)
  for (let r = 0; r <= size - winCount; r++) {
    for (let c = winCount - 1; c < size; c++) {
      const startIdx = r * size + c;
      if (!board[startIdx]) continue;
      const line = [startIdx];
      let match = true;
      for (let k = 1; k < winCount; k++) {
        const idx = (r + k) * size + (c - k);
        if (board[idx] !== board[startIdx]) {
          match = false;
          break;
        }
        line.push(idx);
      }
      if (match) return { winner: board[startIdx], winningLine: line };
    }
  }

  if (!board.includes(null)) return { winner: 'Draw', winningLine: null };
  return { winner: null, winningLine: null };
};

const evaluateHeuristic = (board: Player[], difficulty: Difficulty): number => {
  const { winner } = checkWinner(board, difficulty);
  if (winner === 'O') return 1000;
  if (winner === 'X') return -1000;
  if (winner === 'Draw') return 0;
  return 0;
};

const minimax = (board: Player[], depth: number, isMaximizing: boolean, difficulty: Difficulty, alpha: number, beta: number): number => {
  const { winner } = checkWinner(board, difficulty);
  const { maxDepth } = getBoardConfig(difficulty);

  if (winner === 'O') return 100 - depth;
  if (winner === 'X') return depth - 100;
  if (winner === 'Draw') return 0;
  if (depth >= maxDepth) return evaluateHeuristic(board, difficulty);

  if (isMaximizing) {
    let bestScore = -Infinity;
    for (let i = 0; i < board.length; i++) {
      if (board[i] === null) {
        board[i] = 'O';
        const score = minimax(board, depth + 1, false, difficulty, alpha, beta);
        board[i] = null;
        bestScore = Math.max(score, bestScore);
        alpha = Math.max(alpha, bestScore);
        if (beta <= alpha) break;
      }
    }
    return bestScore;
  } else {
    let bestScore = Infinity;
    for (let i = 0; i < board.length; i++) {
      if (board[i] === null) {
        board[i] = 'X';
        const score = minimax(board, depth + 1, true, difficulty, alpha, beta);
        board[i] = null;
        bestScore = Math.min(score, bestScore);
        beta = Math.min(beta, bestScore);
        if (beta <= alpha) break;
      }
    }
    return bestScore;
  }
};

export const getBestMove = (board: Player[], difficulty: Difficulty): number => {
  if (difficulty === Difficulty.EASY) {
    const available = board.map((v, i) => v === null ? i : null).filter(v => v !== null) as number[];
    if (Math.random() > 0.4) {
       return available[Math.floor(Math.random() * available.length)];
    }
  }

  let bestScore = -Infinity;
  let move = -1;
  const tempBoard = [...board];
  
  for (let i = 0; i < tempBoard.length; i++) {
    if (tempBoard[i] === null) {
      tempBoard[i] = 'O';
      const score = minimax(tempBoard, 0, false, difficulty, -Infinity, Infinity);
      tempBoard[i] = null;
      if (score > bestScore) {
        bestScore = score;
        move = i;
      }
    }
  }
  return move;
};
